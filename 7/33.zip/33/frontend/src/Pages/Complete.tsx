import React from "react";

const Complete = () => {
  return <div>Complete</div>;
};

export default Complete;
