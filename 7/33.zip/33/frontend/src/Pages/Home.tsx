import React from "react";

const home = () => {
  return (
    <div>
      <h1>Hello User!</h1>
    </div>
  );
};

export default home;
