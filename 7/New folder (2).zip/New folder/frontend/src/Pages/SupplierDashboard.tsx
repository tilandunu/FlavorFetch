import React from "react";
//import { BrowserRouter,Routes,Route } from "react-router-dom";
//import'bootstrap/dist/css/bootstrap.min.css'
//import { User, Users } from "lucide-react";
//import CreateUser from "./CreateUser";
//import UpdateUsers from "./UpdateUser";

const SupplierDashboard = () => {
  return (
    <div>
    
    </div>
  );
};

export default SupplierDashboard;