import React from "react";

const DriverDashboard = () => {
  return (
    <div>
      <h1>Hello Driver!</h1>
    </div>
  );
};

export default DriverDashboard;
