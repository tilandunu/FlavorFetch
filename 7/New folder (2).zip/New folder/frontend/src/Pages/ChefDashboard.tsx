import React from "react";

const ChefDashboard = () => {
  return (
    <div>
      <h1>Hello Chef!</h1>
    </div>
  );
};

export default ChefDashboard;
